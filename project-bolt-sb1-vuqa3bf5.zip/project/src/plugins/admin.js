export default {
    name: 'admin',
    description: 'Admin and management commands',
    
    handler: async (event, client, config) => {
        if (!event.message || !event.message.text) return;
        
        const text = event.message.text;
        const isOwner = event.message.senderId?.toString() === config.owner;
        
        if (!text.startsWith(config.prefix) || !isOwner) return;
        
        const command = text.slice(config.prefix.length).split(' ')[0].toLowerCase();
        const args = text.slice(config.prefix.length).split(' ').slice(1);
        
        switch (command) {
            case 'purge':
                const count = parseInt(args[0]) || 10;
                if (count > 100) {
                    await event.reply('❌ Cannot purge more than 100 messages at once!');
                    return;
                }
                
                try {
                    const messages = await client.getMessages(event.chatId, { limit: count });
                    const messageIds = messages.map(msg => msg.id);
                    
                    await client.deleteMessages(event.chatId, messageIds, { revoke: true });
                    
                    const confirmMsg = await event.reply(`🗑️ Purged ${messageIds.length} messages!`);
                    setTimeout(async () => {
                        try {
                            await confirmMsg.delete();
                        } catch (e) {}
                    }, 3000);
                } catch (error) {
                    await event.reply('❌ Failed to purge messages!');
                }
                break;
                
            case 'info':
                const chat = await event.getChat();
                const me = await client.getMe();
                
                let chatInfo = `
📊 **Chat Information:**

**Chat ID:** \`${event.chatId}\`
**Chat Type:** ${chat.className}
**My ID:** \`${me.id}\`
**My Username:** @${me.username || 'N/A'}
                `;
                
                if (chat.title) {
                    chatInfo += `\n**Chat Title:** ${chat.title}`;
                }
                
                if (chat.participantsCount) {
                    chatInfo += `\n**Members:** ${chat.participantsCount}`;
                }
                
                await event.reply(chatInfo);
                break;
                
            case 'stats':
                const uptime = process.uptime();
                const hours = Math.floor(uptime / 3600);
                const minutes = Math.floor((uptime % 3600) / 60);
                const seconds = Math.floor(uptime % 60);
                
                const stats = `
📈 **Bot Statistics:**

**Uptime:** ${hours}h ${minutes}m ${seconds}s
**Memory Usage:** ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB
**Node Version:** ${process.version}
**Platform:** ${process.platform}
**Prefix:** \`${config.prefix}\`
                `;
                
                await event.reply(stats);
                break;
                
            case 'eval':
                if (!isOwner) return;
                
                const code = args.join(' ');
                if (!code) {
                    await event.reply('❌ Please provide code to evaluate!');
                    return;
                }
                
                try {
                    let result = eval(code);
                    if (typeof result === 'object') {
                        result = JSON.stringify(result, null, 2);
                    }
                    await event.reply(`\`\`\`javascript\n${result}\n\`\`\``);
                } catch (error) {
                    await event.reply(`❌ **Error:**\n\`\`\`\n${error.message}\n\`\`\``);
                }
                break;
                
            case 'restart':
                await event.reply('🔄 Restarting bot...');
                process.exit(0);
                break;
                
            case 'prefix':
                const newPrefix = args[0];
                if (!newPrefix) {
                    await event.reply(`Current prefix: \`${config.prefix}\``);
                    return;
                }
                
                config.prefix = newPrefix;
                await event.reply(`✅ Prefix changed to: \`${newPrefix}\``);
                break;
        }
    }
};