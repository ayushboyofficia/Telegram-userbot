import { Api } from 'telegram';

const ANIMATIONS = {
    heart: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎'],
    loading: ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'],
    clock: ['🕐', '🕑', '🕒', '🕓', '🕔', '🕕', '🕖', '🕗', '🕘', '🕙', '🕚', '🕛'],
    moon: ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘'],
    earth: ['🌍', '🌎', '🌏'],
    fire: ['🔥', '💥', '✨', '⭐', '🌟', '💫', '⚡'],
    dance: ['🕺', '💃', '🕺', '💃', '🕺', '💃'],
    rain: ['☔', '🌧️', '⛈️', '🌩️', '🌦️'],
    snake: ['🐍', '🐍🐍', '🐍🐍🐍', '🐍🐍🐍🐍', '🐍🐍🐍🐍🐍'],
    typing: ['t', 'ty', 'typ', 'typi', 'typin', 'typing', 'typing.', 'typing..', 'typing...']
};

const TEXTS = {
    matrix: [
        '█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█',
        '█ MATRIX LOADING... █',
        '█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█',
        '▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓',
        '░░░░░░░░░░░░░░░░░░░░'
    ],
    hack: [
        '🔴 INITIALIZING HACK...',
        '🟡 CONNECTING TO SERVER...',
        '🟢 ACCESS GRANTED!',
        '💀 SYSTEM COMPROMISED',
        '🔥 HACK COMPLETE!'
    ]
};

async function animateMessage(event, frames, delay = 1000) {
    const message = await event.reply(frames[0]);
    
    for (let i = 1; i < frames.length; i++) {
        await new Promise(resolve => setTimeout(resolve, delay));
        try {
            await message.edit(frames[i]);
        } catch (error) {
            console.error('Animation error:', error);
            break;
        }
    }
    
    return message;
}

async function infiniteAnimation(event, frames, delay = 500, duration = 10000) {
    const message = await event.reply(frames[0]);
    const startTime = Date.now();
    let frameIndex = 0;
    
    const animate = async () => {
        if (Date.now() - startTime >= duration) {
            return;
        }
        
        try {
            await message.edit(frames[frameIndex]);
            frameIndex = (frameIndex + 1) % frames.length;
            setTimeout(animate, delay);
        } catch (error) {
            console.error('Infinite animation error:', error);
        }
    };
    
    setTimeout(animate, delay);
    return message;
}

export default {
    name: 'animations',
    description: 'Cool animation commands',
    
    handler: async (event, client, config) => {
        if (!event.message || !event.message.text) return;
        
        const text = event.message.text;
        const isOwner = event.message.senderId?.toString() === config.owner;
        
        if (!text.startsWith(config.prefix) || !isOwner) return;
        
        const command = text.slice(config.prefix.length).split(' ')[0].toLowerCase();
        const args = text.slice(config.prefix.length).split(' ').slice(1);
        
        switch (command) {
            case 'heart':
                await infiniteAnimation(event, ANIMATIONS.heart, 300, 8000);
                break;
                
            case 'loading':
                await infiniteAnimation(event, ANIMATIONS.loading, 100, 5000);
                break;
                
            case 'clock':
                await infiniteAnimation(event, ANIMATIONS.clock, 500, 12000);
                break;
                
            case 'moon':
                await infiniteAnimation(event, ANIMATIONS.moon, 400, 6000);
                break;
                
            case 'earth':
                await infiniteAnimation(event, ANIMATIONS.earth, 800, 8000);
                break;
                
            case 'fire':
                await infiniteAnimation(event, ANIMATIONS.fire, 200, 6000);
                break;
                
            case 'dance':
                await infiniteAnimation(event, ANIMATIONS.dance, 300, 9000);
                break;
                
            case 'rain':
                await infiniteAnimation(event, ANIMATIONS.rain, 600, 10000);
                break;
                
            case 'snake':
                await animateMessage(event, ANIMATIONS.snake, 800);
                break;
                
            case 'typing':
                await animateMessage(event, ANIMATIONS.typing, 200);
                break;
                
            case 'matrix':
                await animateMessage(event, TEXTS.matrix, 1000);
                break;
                
            case 'hack':
                await animateMessage(event, TEXTS.hack, 1500);
                break;
                
            case 'boom':
                const boom = ['💣', '💥', '🔥', '💀', '☠️'];
                await animateMessage(event, boom, 800);
                break;
                
            case 'love':
                const love = ['❤️', '💕', '💖', '💗', '💓', '💞', '💘', '💝'];
                await infiniteAnimation(event, love, 400, 8000);
                break;
                
            case 'wave':
                const wave = ['👋', '👋🏻', '👋🏼', '👋🏽', '👋🏾', '👋🏿'];
                await infiniteAnimation(event, wave, 300, 5000);
                break;
                
            case 'rainbow':
                const rainbow = ['🔴', '🟠', '🟡', '🟢', '🔵', '🟣', '🟤', '⚫', '⚪'];
                await infiniteAnimation(event, rainbow, 200, 7000);
                break;
        }
    }
};