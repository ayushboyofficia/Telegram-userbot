import axios from 'axios';

const REACTIONS = {
    happy: ['😊', '😄', '😃', '😁', '😆', '🤣', '😂', '🙂', '🙃', '😉'],
    sad: ['😢', '😭', '😿', '💔', '😞', '😔', '😟', '😕', '🙁', '☹️'],
    angry: ['😠', '😡', '🤬', '👿', '💢', '😤', '😾', '🗯️', '💥', '🔥'],
    love: ['😍', '🥰', '😘', '💕', '💖', '💗', '💓', '💞', '💘', '💝'],
    cool: ['😎', '🕶️', '😏', '🤓', '🧐', '🤠', '🥸', '🤡', '🥳', '🤩']
};

const QUOTES = [
    "Life is what happens to you while you're busy making other plans. - John Lennon",
    "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
    "It is during our darkest moments that we must focus to see the light. - Aristotle",
    "The only impossible journey is the one you never begin. - Tony Robbins",
    "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill"
];

const JOKES = [
    "Why don't scientists trust atoms? Because they make up everything!",
    "Why did the scarecrow win an award? He was outstanding in his field!",
    "Why don't eggs tell jokes? They'd crack each other up!",
    "What do you call a fake noodle? An impasta!",
    "Why did the math book look so sad? Because it had too many problems!"
];

export default {
    name: 'fun',
    description: 'Fun and entertainment commands',
    
    handler: async (event, client, config) => {
        if (!event.message || !event.message.text) return;
        
        const text = event.message.text;
        const isOwner = event.message.senderId?.toString() === config.owner;
        
        if (!text.startsWith(config.prefix) || !isOwner) return;
        
        const command = text.slice(config.prefix.length).split(' ')[0].toLowerCase();
        const args = text.slice(config.prefix.length).split(' ').slice(1);
        
        switch (command) {
            case 'react':
                const mood = args[0] || 'happy';
                const reactions = REACTIONS[mood] || REACTIONS.happy;
                const reaction = reactions[Math.floor(Math.random() * reactions.length)];
                await event.reply(`${reaction} ${mood.toUpperCase()} MOOD! ${reaction}`);
                break;
                
            case 'quote':
                const quote = QUOTES[Math.floor(Math.random() * QUOTES.length)];
                await event.reply(`💭 **Random Quote:**\n\n*${quote}*`);
                break;
                
            case 'joke':
                const joke = JOKES[Math.floor(Math.random() * JOKES.length)];
                await event.reply(`😂 **Random Joke:**\n\n${joke}`);
                break;
                
            case 'flip':
                const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
                await event.reply(`🪙 **Coin Flip Result:** ${result}!`);
                break;
                
            case 'dice':
                const dice = Math.floor(Math.random() * 6) + 1;
                await event.reply(`🎲 **Dice Roll:** ${dice}`);
                break;
                
            case '8ball':
                const responses = [
                    'Yes definitely!', 'It is certain', 'Without a doubt',
                    'Yes', 'Most likely', 'Outlook good',
                    'Reply hazy, try again', 'Ask again later', 'Better not tell you now',
                    'Cannot predict now', 'Concentrate and ask again',
                    'Don\'t count on it', 'My reply is no', 'My sources say no',
                    'Outlook not so good', 'Very doubtful'
                ];
                const response = responses[Math.floor(Math.random() * responses.length)];
                await event.reply(`🎱 **Magic 8-Ball says:** ${response}`);
                break;
                
            case 'choose':
                if (args.length < 2) {
                    await event.reply('❌ Please provide at least 2 options separated by spaces!');
                    return;
                }
                const choice = args[Math.floor(Math.random() * args.length)];
                await event.reply(`🤔 **I choose:** ${choice}`);
                break;
                
            case 'reverse':
                const textToReverse = args.join(' ');
                if (!textToReverse) {
                    await event.reply('❌ Please provide text to reverse!');
                    return;
                }
                const reversed = textToReverse.split('').reverse().join('');
                await event.reply(`🔄 **Reversed:** ${reversed}`);
                break;
                
            case 'mock':
                const textToMock = args.join(' ');
                if (!textToMock) {
                    await event.reply('❌ Please provide text to mock!');
                    return;
                }
                const mocked = textToMock.split('').map((char, i) => 
                    i % 2 === 0 ? char.toLowerCase() : char.toUpperCase()
                ).join('');
                await event.reply(`🤡 **Mocked:** ${mocked}`);
                break;
                
            case 'ascii':
                const asciiText = args.join(' ');
                if (!asciiText) {
                    await event.reply('❌ Please provide text for ASCII art!');
                    return;
                }
                // Simple ASCII art generator
                const ascii = asciiText.split('').map(char => {
                    switch(char.toLowerCase()) {
                        case 'a': return '█▀█\n█▀█\n▀ █';
                        case 'b': return '██▀\n██▀\n██▄';
                        case 'c': return '▄▀█\n█▄▄\n▀▀▀';
                        default: return char;
                    }
                }).join(' ');
                await event.reply(`\`\`\`\n${ascii}\n\`\`\``);
                break;
        }
    }
};