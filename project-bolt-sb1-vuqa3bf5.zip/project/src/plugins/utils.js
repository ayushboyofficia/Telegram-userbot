import moment from 'moment';
import axios from 'axios';

export default {
    name: 'utils',
    description: 'Utility commands',
    
    handler: async (event, client, config) => {
        if (!event.message || !event.message.text) return;
        
        const text = event.message.text;
        const isOwner = event.message.senderId?.toString() === config.owner;
        
        if (!text.startsWith(config.prefix) || !isOwner) return;
        
        const command = text.slice(config.prefix.length).split(' ')[0].toLowerCase();
        const args = text.slice(config.prefix.length).split(' ').slice(1);
        
        switch (command) {
            case 'time':
                const now = moment();
                await event.reply(`🕐 **Current Time:**\n${now.format('LLLL')}`);
                break;
                
            case 'ping':
                const start = Date.now();
                const msg = await event.reply('🏓 Pinging...');
                const end = Date.now();
                await msg.edit(`🏓 **Pong!** \`${end - start}ms\``);
                break;
                
            case 'calc':
                const expression = args.join(' ');
                if (!expression) {
                    await event.reply('❌ Please provide a mathematical expression!');
                    return;
                }
                try {
                    // Simple calculator (be careful with eval in production)
                    const result = Function(`"use strict"; return (${expression})`)();
                    await event.reply(`🧮 **Result:** \`${expression} = ${result}\``);
                } catch (error) {
                    await event.reply('❌ Invalid mathematical expression!');
                }
                break;
                
            case 'weather':
                const city = args.join(' ');
                if (!city) {
                    await event.reply('❌ Please provide a city name!');
                    return;
                }
                try {
                    // Note: You'll need to get a free API key from OpenWeatherMap
                    await event.reply('🌤️ Weather feature requires API key setup!');
                } catch (error) {
                    await event.reply('❌ Could not fetch weather data!');
                }
                break;
                
            case 'shorten':
                const url = args[0];
                if (!url) {
                    await event.reply('❌ Please provide a URL to shorten!');
                    return;
                }
                // Simple URL shortener placeholder
                await event.reply('🔗 URL shortener feature coming soon!');
                break;
                
            case 'qr':
                const qrText = args.join(' ');
                if (!qrText) {
                    await event.reply('❌ Please provide text for QR code!');
                    return;
                }
                const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrText)}`;
                await event.reply(`📱 **QR Code for:** ${qrText}\n${qrUrl}`);
                break;
                
            case 'base64':
                const action = args[0];
                const data = args.slice(1).join(' ');
                
                if (!action || !data) {
                    await event.reply('❌ Usage: .base64 encode/decode <text>');
                    return;
                }
                
                try {
                    if (action === 'encode') {
                        const encoded = Buffer.from(data, 'utf8').toString('base64');
                        await event.reply(`🔐 **Encoded:** \`${encoded}\``);
                    } else if (action === 'decode') {
                        const decoded = Buffer.from(data, 'base64').toString('utf8');
                        await event.reply(`🔓 **Decoded:** \`${decoded}\``);
                    } else {
                        await event.reply('❌ Use "encode" or "decode"');
                    }
                } catch (error) {
                    await event.reply('❌ Invalid base64 data!');
                }
                break;
                
            case 'hash':
                const hashText = args.join(' ');
                if (!hashText) {
                    await event.reply('❌ Please provide text to hash!');
                    return;
                }
                
                const crypto = await import('crypto');
                const md5 = crypto.createHash('md5').update(hashText).digest('hex');
                const sha1 = crypto.createHash('sha1').update(hashText).digest('hex');
                const sha256 = crypto.createHash('sha256').update(hashText).digest('hex');
                
                await event.reply(`🔐 **Hashes for:** \`${hashText}\`\n\n**MD5:** \`${md5}\`\n**SHA1:** \`${sha1}\`\n**SHA256:** \`${sha256}\``);
                break;
                
            case 'help':
                const helpText = `
🤖 **Userbot Commands:**

**🎨 Animations:**
\`.heart\` - Heart animation
\`.loading\` - Loading spinner
\`.clock\` - Clock animation
\`.moon\` - Moon phases
\`.fire\` - Fire animation
\`.dance\` - Dance animation
\`.matrix\` - Matrix style
\`.hack\` - Hacker animation

**🎮 Fun:**
\`.react <mood>\` - Random reactions
\`.quote\` - Random quote
\`.joke\` - Random joke
\`.flip\` - Coin flip
\`.dice\` - Roll dice
\`.8ball\` - Magic 8-ball
\`.choose <options>\` - Choose randomly

**🛠️ Utils:**
\`.time\` - Current time
\`.ping\` - Check latency
\`.calc <expression>\` - Calculator
\`.qr <text>\` - Generate QR code
\`.base64 encode/decode <text>\`
\`.hash <text>\` - Generate hashes

Type \`.help\` to see this menu again!
                `;
                await event.reply(helpText);
                break;
        }
    }
};